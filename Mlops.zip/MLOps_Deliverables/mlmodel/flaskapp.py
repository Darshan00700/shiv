from flask import Flask, render_template, request
from joblib import load
import numpy as np

app = Flask(__name__)
model = load("SpamModel.pkl")
vectorizer = load("Vectorizer.pkl")

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def make_prediction():
    input_text = request.form['email_text']
    input_text_vectorized = vectorizer.transform([input_text])
    prediction = model.predict(input_text_vectorized)[0]

    return render_template("result.html", prediction=prediction)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=80)

 
