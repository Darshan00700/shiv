from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, classification_report
from joblib import dump
import pandas as pd

# Load the Spam Email dataset
df = pd.read_csv("spam_email_data.csv")

# Separate features (email text) and target variable (spam or not)
X = df['text']
y = df['label']

# Convert text data to numerical features using CountVectorizer
vectorizer = CountVectorizer()
X_vectorized = vectorizer.fit_transform(X)

# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X_vectorized, y, test_size=0.2, random_state=42)

# Create a Naive Bayes classifier
classifier = MultinomialNB()

# Train the model
classifier.fit(X_train, y_train)

# Make predictions on the test set
y_pred = classifier.predict(X_test)

# Evaluate the model accuracy and print classification report
accuracy = accuracy_score(y_test, y_pred)
print(f"Model Accuracy: {accuracy}")
print("Classification Report:\n", classification_report(y_test, y_pred))

# Save the model and vectorizer
dump(classifier, "SpamModel.pkl")
dump(vectorizer, "Vectorizer.pkl")

